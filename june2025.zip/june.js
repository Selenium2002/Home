window.addEventListener("scroll", ()=> {
    let navbar = document.querySelector("nav");
    navbar.classList.toggle("sticky", window.scrollY > 0);
})

const sidebar = document.querySelector(".sidebar"); 

function showSidebar(){
    sidebar.style.display = "flex"
}

function hideSidebar(){
    sidebar.style.display = "none"
}